<?php
/*
Plugin Name: WellExpo Instagram Feed
Description: Plugin that adds Instagram feed functionality to our theme
Author: Select Themes
Version: 1.0
*/
define('WELLEXPO_INSTAGRAM_FEED_VERSION', '1.0');
define('WELLEXPO_INSTAGRAM_ABS_PATH', dirname(__FILE__));
define('WELLEXPO_INSTAGRAM_REL_PATH', dirname(plugin_basename(__FILE__ )));
define( 'WELLEXPO_INSTAGRAM_URL_PATH', plugin_dir_url( __FILE__ ) );
define( 'WELLEXPO_INSTAGRAM_ASSETS_PATH', WELLEXPO_INSTAGRAM_ABS_PATH . '/assets' );
define( 'WELLEXPO_INSTAGRAM_ASSETS_URL_PATH', WELLEXPO_INSTAGRAM_URL_PATH . 'assets' );
define( 'WELLEXPO_INSTAGRAM_SHORTCODES_PATH', WELLEXPO_INSTAGRAM_ABS_PATH . '/shortcodes' );
define( 'WELLEXPO_INSTAGRAM_SHORTCODES_URL_PATH', WELLEXPO_INSTAGRAM_URL_PATH . 'shortcodes' );

include_once 'load.php';

if ( ! function_exists( 'wellexpo_instagram_theme_installed' ) ) {
    /**
     * Checks whether theme is installed or not
     * @return bool
     */
    function wellexpo_instagram_theme_installed() {
        return defined( 'SELECT_ROOT' );
    }
}

if ( ! function_exists( 'wellexpo_instagram_feed_text_domain' ) ) {
	/**
	 * Loads plugin text domain so it can be used in translation
	 */
	function wellexpo_instagram_feed_text_domain() {
		load_plugin_textdomain( 'wellexpo-instagram-feed', false, WELLEXPO_INSTAGRAM_REL_PATH . '/languages' );
	}
	
	add_action( 'plugins_loaded', 'wellexpo_instagram_feed_text_domain' );
}