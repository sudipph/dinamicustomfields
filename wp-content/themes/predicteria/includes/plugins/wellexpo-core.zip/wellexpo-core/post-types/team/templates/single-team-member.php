<?php

get_header();

wellexpo_select_get_title();

do_action('wellexpo_select_action_before_main_content');

wellexpo_core_get_single_team();

get_footer();