<?php

include_once WELLEXPO_CORE_SHORTCODES_PATH . '/google-map-with-contact-form/functions.php';
include_once WELLEXPO_CORE_SHORTCODES_PATH . '/google-map-with-contact-form/google-map-with-contact-form.php';