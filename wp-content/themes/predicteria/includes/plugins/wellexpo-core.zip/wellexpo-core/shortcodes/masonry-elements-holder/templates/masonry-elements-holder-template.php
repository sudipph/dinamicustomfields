<div <?php wellexpo_select_class_attribute( $holder_classes ); ?>>
	<div class="qodef-masonry-elements-grid-sizer"></div>
	<?php echo do_shortcode( $content ); ?>
</div>