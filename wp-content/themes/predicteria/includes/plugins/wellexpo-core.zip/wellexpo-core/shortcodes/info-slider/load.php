<?php

include_once WELLEXPO_CORE_SHORTCODES_PATH . '/info-slider/functions.php';
include_once WELLEXPO_CORE_SHORTCODES_PATH . '/info-slider/info-slider.php';