<div class="qodef-team-single-content">
	<?php the_content(); ?>
</div>